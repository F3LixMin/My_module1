package com.example.mymoduile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class C346 extends AppCompatActivity {
    TextView modcode;
    TextView modName;
    TextView AcadYr;
    TextView Sem;
    TextView Credit;
    TextView Venue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c346);

        modcode = findViewById(R.id.ModuleCode);
        modName = findViewById(R.id.Modulenamechar);
        AcadYr = findViewById(R.id.Academicyear);
        Sem = findViewById(R.id.Semesterint);
        Credit = findViewById(R.id.Modulecreaditint);
        Venue = findViewById(R.id.Venue);

        Intent C = getIntent();
        modcode.setText("Module code: " + C.getStringExtra("modulecode"));
        modName.setText("Module Name: " + C.getStringExtra("modulename"));
        AcadYr.setText("Academic Year: " + C.getIntExtra("Academic year", 2020));
        Sem.setText("Semester: " + C.getIntExtra("Semester", 1));
        Credit.setText("Module Credit: " + C.getIntExtra("Module Credit", 4));
        Venue.setText("Venue: " + C.getStringExtra("Venue"));
    }
}