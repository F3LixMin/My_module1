package com.example.mymoduile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class C206 extends AppCompatActivity {

TextView modulecode;
TextView modulename;
TextView Academic;
TextView Semester;
TextView Modulecred;
TextView Venue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c206);

        modulecode = findViewById(R.id.textView3);
        modulename = findViewById(R.id.textView4);
        Academic = findViewById(R.id.textView5);
        Semester = findViewById(R.id.textView6);
        Modulecred = findViewById(R.id.textView7);
        Venue = findViewById(R.id.textView8);

        Intent G = getIntent();
        modulecode.setText("Module code: " + G.getStringExtra("modulecode"));
        modulename.setText("Module name: " + G.getStringExtra("modulename"));
        Academic.setText("Academic year: " + G.getStringExtra("Academic year"));
        Semester.setText("Semester" + G.getStringExtra("Semester"));
        Modulecred.setText("Module creadit: " + G.getStringExtra("Module Credit"));
        Venue.setText("Venue: " + G.getStringExtra("Venue"));
    }
}