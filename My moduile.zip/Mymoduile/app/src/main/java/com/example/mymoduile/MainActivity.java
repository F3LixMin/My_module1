package com.example.mymoduile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView C346;
    TextView C206;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        C346 = findViewById(R.id.textView);
        C206 = findViewById(R.id.textView2);

        C346.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, C346.class);
                intent.putExtra("modulecode", "C346");
                intent.putExtra("modulename", "Android programming");
                intent.putExtra("Academic year", "2020");
                intent.putExtra("Semester", "1");
                intent.putExtra("Module Credit", "4");
                intent.putExtra("Venue ", "W66M");
                startActivity(intent);

            }
        });
        C206.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, C206.class);
                intent.putExtra("modulecode", "C206");
                intent.putExtra("modulename", "Android programming");
                intent.putExtra("Academic year", "2020");
                intent.putExtra("Semester", "1");
                intent.putExtra("Module Credit", "4");
                intent.putExtra("Venue", "E66K");
                startActivity(intent);
            }
        });
    }
}